<div id="wrapper">

    <!-- Sidebar -->
    <?php $this->load->view('templates/sidebar') ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <?php $this->load->view('templates/topbar') ?>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
                <div class="card">
                    <div class="card-body">
                        
                                <center>
                                <img src="<?= base_url('vendor/') ?>img/logo.png" width="100"><br><small><i>Logo BEM Fakultas Teknik</i></small><br><br>
                                <p style="text-align: center;">BEM Fakultas Teknik merupakan sebuah organisasi intra kampus yang berada di Universitas Mandiri. 
                                </p>
                                </center>
                                <h3>Visi</h3>
                                <p style="text-align: justify;"><i>“Menjadikan BEM Fakultas Teknik Universitas Mandiri sebagai wadah yang aktif dalam mengembangkan potensi mahasiswa demi mewujudkan kepribadian yang unggul, berkarakter, serta berakhlakul karimah”.</i> </p>
                                <h3>Misi</h3>
                                <ol>
                                    <li>Menjadikan pengurus BEM Fakultas Teknik yang taat kepada Tuhan Yang Maha Esa dan berakhlakul karimah serta mampu memposisikan diri dalam berbagai kondisi yang tersimpul dalam sikap bajik dan bijak.</li>
                                    <li>Memfasilitasi pengembangan minat dan bakat mahasiswa Fakultas Teknik.</li>
                                    <li>Menjungjung tinggi nilai apresiasi, solidaritas dan kolaboratif.</li>
                                    <li>Meningkatkan kinerja organisasi BEM Fakultas Teknik dengan memanfaatkan teknologi informasi.</li>
                                    <li>Mengasah dan memaksimalkan potensi-potensi yang ada dalam setiap individu pengurus BEM Fakultas Teknik.</li>
                                    <li>Ikut andil mempromosikan kampus ke dalam masyarakat luas.</li>
                                    <li>Melaksanakan pengabdian kepada masyarakat dengan dasar ilmu yang telah dipelajari di Fakultas Teknik.</li>
                                </ol>
                            </div>
                        
                    </div>
                </div>
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <?php $this->load->view('templates/copyright') ?>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

</div>